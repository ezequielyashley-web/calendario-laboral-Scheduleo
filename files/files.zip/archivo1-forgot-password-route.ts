// app/api/auth/forgot-password/route.ts
import { NextRequest, NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import crypto from "crypto"

const prisma = new PrismaClient()

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json()

    if (!email) {
      return NextResponse.json(
        { error: "Email es requerido" },
        { status: 400 }
      )
    }

    // Buscar usuario
    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    })

    // Siempre retornar éxito (seguridad: no revelar si el email existe)
    if (!user) {
      return NextResponse.json({
        message: "Si el email existe, recibirás instrucciones para restablecer tu contraseña",
      })
    }

    // Invalidar tokens anteriores del usuario
    await prisma.passwordResetToken.updateMany({
      where: {
        userId: user.id,
        used: false,
      },
      data: {
        used: true,
      },
    })

    // Generar token seguro
    const resetToken = crypto.randomBytes(32).toString("hex")
    const expires = new Date(Date.now() + 3600000) // 1 hora

    // Crear token en BD
    await prisma.passwordResetToken.create({
      data: {
        token: resetToken,
        userId: user.id,
        expires,
      },
    })

    // Generar URL de restablecimiento
    const resetUrl = `${process.env.NEXTAUTH_URL}/reset-password?token=${resetToken}`

    // TODO: Aquí deberías enviar el email con el resetUrl
    // Por ahora, lo retornamos en la respuesta (SOLO PARA DESARROLLO)
    console.log("🔐 Token de restablecimiento:", resetUrl)

    return NextResponse.json({
      message: "Si el email existe, recibirás instrucciones para restablecer tu contraseña",
      // REMOVER EN PRODUCCIÓN:
      resetUrl: process.env.NODE_ENV === "development" ? resetUrl : undefined,
    })
  } catch (error) {
    console.error("Error en forgot-password:", error)
    return NextResponse.json(
      { error: "Error al procesar solicitud" },
      { status: 500 }
    )
  }
}
